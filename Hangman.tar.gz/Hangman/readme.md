# El Ahorcado
## **En fase de desarrollo**
Este juego lo estoy creando ahora y seguramente tenga algunos errores que iré solucionando con el tiempo

Tengo pensado añadirle al juego un par de opciones con elección de idioma, nivel de dificultad y cualquier otra que se me ocurra.

Este es mi primer script y me ha costado unos días terminarlo del todo. Acepto cualquier tipo de sugerencias y ayudas para mejorar el script.

Con esto quiero empezar a crear una serie de juegos y herramientas que iré subiendo en mi Github y que quedarán en formato libre.